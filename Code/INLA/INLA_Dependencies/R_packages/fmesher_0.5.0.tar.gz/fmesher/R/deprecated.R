#' Deprecated functions in fmesher
#'
#' These functions still attempt to do their job, but will be removed in a
#' future version.
#'
#' @param \dots Usually passed on to other methods
#'
#' @author Finn Lindgren <Finn.Lindgren@@gmail.com>
#'
#' @name fmesher-deprecated
NULL
