# test_that("base graphics plotting", {
#   plot(fmexample$mesh)
#
#   plot(fmexample$boundary_fm)
# })
#
# test_that("rgl plotting", {
#   skip_if_not_installed("rgl")
#
#   plot_rgl(fmexample$mesh)
#
#   plot_rgl(fmexample$boundary_fm)
# })
