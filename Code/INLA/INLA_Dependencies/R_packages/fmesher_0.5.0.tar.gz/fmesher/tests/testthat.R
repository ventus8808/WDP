library(testthat)
library(fmesher)

test_check("fmesher")
